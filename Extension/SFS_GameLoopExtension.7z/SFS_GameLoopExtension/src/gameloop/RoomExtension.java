package gameloop;

import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.extensions.SFSExtension;

public class RoomExtension extends SFSExtension
{
	private SmartFoxServer sfs;
	private Game game;
	private ScheduledFuture<?> gameTask;
	@Override
	public void init() 
	{
		
		// Get a reference to the SmartFoxServer instance
		sfs = SmartFoxServer.getInstance();
		game = new Game(this);
		gameTask = sfs.getTaskScheduler().scheduleAtFixedRate(game, 0, 33, TimeUnit.MILLISECONDS);
	}
	@Override
	public void destroy()
	{
		gameTask.cancel(true);
	}

}
